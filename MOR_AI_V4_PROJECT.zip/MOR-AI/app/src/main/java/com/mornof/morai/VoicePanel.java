package com.mornof.morai;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.app.AlertDialog;
import android.telephony.SmsManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;
import android.text.TextUtils;
import android.os.SystemClock;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** MOR AI V3 local voice/action prototype. Does not transmit contacts or messages to a server. */
public class VoicePanel {
    private final Context ctx;
    private final Runnable settingsAction;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Locale he = new Locale("he", "IL");
    private final int BACK=0xff071322, PANEL=0xff15273c, AQUA=0xff28dfd0, MUTED=0xff9dafc8;
    private TextView state, transcript;
    private VoiceOrb orb;
    private Button mic;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean listening=false, closed=false, speaking=false;
    private String pendingName="", pendingNumber="", pendingBody="", pendingChannel="";
    private enum Mode { IDLE, CALL_NAME, CONTACT_DISAMBIGUATION, MESSAGE_RECIPIENT, MESSAGE_BODY, MESSAGE_CONFIRM, COMMAND_FOLLOWUP, CALL_CONFIRM }
    private Mode mode=Mode.IDLE;
    private List<Contact> alternatives = new ArrayList<>();
    private String requestedChannel="";
    private final Runnable followupTimeout = () -> { if(!closed && mode!=Mode.IDLE) { mode=Mode.IDLE; say("לא קיבלתי תשובה. אפשר להתחיל שוב."); } };
    private boolean allowAutoCall=true;
    private long lastCommandTime=0;
    private String preferredVoice="";
    private View view;
    private final Runnable hardTimeout = () -> { if(listening){ stopListening(); status("לא התקבל דיבור — אפשר לנסות שוב"); }};

    public VoicePanel(Context ctx, Runnable settingsAction) {
        this.ctx=ctx; this.settingsAction=settingsAction;
        build();
        tts=new TextToSpeech(ctx, result -> {
            if(result==TextToSpeech.SUCCESS && tts!=null) {
                tts.setLanguage(he);
                preferredVoice=ctx.getSharedPreferences("morai",0).getString("voice", "");
                applyVoice();
            }
        });
    }
    private int dp(float p){return (int)(p*ctx.getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable background(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable(); d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView txt(String value,int sp,int color,boolean bold){TextView t=new TextView(ctx);t.setText(value);t.setTextColor(color);t.setTextSize(sp);t.setGravity(Gravity.CENTER);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void add(LinearLayout p,View v,int top,int bottom){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(top),0,dp(bottom));p.addView(v,lp);}
    private Button button(String label, int bg){Button b=new Button(ctx);b.setAllCaps(false);b.setText(label);b.setTextSize(17);b.setTextColor(bg==AQUA?BACK:Color.WHITE);b.setBackground(background(bg,22,0));b.setMinHeight(dp(58));return b;}
    private class VoiceOrb extends View {
        private final Paint paint=new Paint(3);
        private float energy=0f;
        private boolean active=false;
        VoiceOrb(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void setActive(boolean b){active=b;invalidate();}
        void setEnergy(float v){energy=Math.min(1f,Math.max(0,v));invalidate();}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);float x=getWidth()/2f,y=getHeight()/2f;
            float r=Math.min(getWidth(),getHeight())*.33f;
            paint.setStyle(Paint.Style.FILL);paint.setColor(0xff103746);c.drawCircle(x,y,r*1.49f,paint);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(0xff20858d);c.drawCircle(x,y,r*1.5f,paint);
            for(int i=0;i<48;i++){
                double theta=i*Math.PI*2/48;
                float wave=(float)(.24+.76*Math.abs(Math.sin(i*.43+SystemClock.uptimeMillis()*.002)));
                float h=dp(active?(6+20*energy*wave):5);
                paint.setStrokeWidth(dp(2.7f));paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setColor(i%3==0?0xff75dceb:0xff24dcca);
                float x1=x+(float)Math.cos(theta)*(r+h*.2f),y1=y+(float)Math.sin(theta)*(r+h*.2f);
                c.drawLine(x1,y1,x1+(float)Math.cos(theta)*h,y1+(float)Math.sin(theta)*h,paint);
            }
            paint.setStyle(Paint.Style.FILL);paint.setColor(active?0xff38e8da:0xff1bbed2);c.drawCircle(x,y,r*.55f,paint);
            paint.setColor(0xff062335);c.drawCircle(x,y,r*.37f,paint);
            if(active) postInvalidateDelayed(60);
        }
    }
    private void build(){
        ScrollView s=new ScrollView(ctx);s.setFillViewport(true);s.setBackgroundColor(BACK);
        LinearLayout root=new LinearLayout(ctx);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(23),dp(33),dp(23),dp(30));s.addView(root);
        add(root,txt("✦  MOR AI",36,Color.WHITE,true),6,4);
        add(root,txt("VOICE DRIVE  •  4.0  |  עוזרת קולית",13,MUTED,false),0,23);
        orb=new VoiceOrb(ctx);
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(dp(238),dp(238));op.setMargins(0,dp(10),0,dp(22));root.addView(orb,op);
        state=txt("מוכנה לפקודה",25,Color.WHITE,true);add(root,state,1,8);
        transcript=txt("'תתקשרי לאלעד'  •  'נווטי לרעננה'  •  'שלחי הודעה לדני'",14,MUTED,false);add(root,transcript,0,28);
        mic=button("🎙  התחילי להקשיב",AQUA);
        mic.setOnClickListener(v->{if(listening)stopListening();else {mode=Mode.IDLE;listen();}});add(root,mic,0,12);
        Button waze=button("⌖  ניווט Waze",PANEL);waze.setOnClickListener(v->{mode=Mode.COMMAND_FOLLOWUP;sayAndListen("לאן לנווט?");});add(root,waze,0,9);
        Button call=button("☎  התקשרות קולית",PANEL);call.setOnClickListener(v->{mode=Mode.CALL_NAME;sayAndListen("למי להתקשר?");});add(root,call,0,9);
        Button message=button("✉  הודעות בקול",PANEL);message.setOnClickListener(v->{requestedChannel="whatsapp";mode=Mode.MESSAGE_RECIPIENT;sayAndListen("למי לשלוח הודעה?");});add(root,message,0,9);
        Button voices=button("♫  בחירת קול",PANEL);voices.setOnClickListener(v->chooseVoice());add(root,voices,0,9);
        Button ass=button("⚙  עוזרת ברירת מחדל",PANEL);ass.setOnClickListener(v->{try{if(settingsAction!=null)settingsAction.run();else open(new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS));}catch(Exception e){status("פתח הגדרות עוזרת דיגיטלית");}});add(root,ass,0,14);
        add(root,txt("בטיחות: הודעות SMS דורשות אישור קולי. WhatsApp נפתחת עם טקסט מוכן ודורשת שליחה באפליקציה. אין מנוע AI חופשי מחובר עדיין.",12,MUTED,false),0,0);
        view=s;
    }
    public View view(){return view;}
    private void status(String v){state.setText(v);mic.setText("🎙  התחילי להקשיב");orb.setActive(false);}
    private void open(Intent i){try{i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);ctx.startActivity(i);}catch(Exception e){status("לא נמצאה אפליקציה מתאימה");}}
    private void say(String v){status(v);if(tts!=null)tts.speak(v,TextToSpeech.QUEUE_FLUSH,null,"mor"+System.currentTimeMillis());}
    private void sayAndListen(String phrase){
        handler.removeCallbacks(followupTimeout);
        status(phrase);
        if(tts!=null){
            tts.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener(){
                @Override public void onStart(String id){}
                @Override public void onDone(String id){handler.postDelayed(()->{if(!closed && mode!=Mode.IDLE)listen();},350);}
                @Override public void onError(String id){handler.post(()->{if(!closed)listen();});}
            });
            tts.speak(phrase,TextToSpeech.QUEUE_FLUSH,null,"followup"+SystemClock.uptimeMillis());
        } else handler.postDelayed(()->listen(),300);
        handler.postDelayed(followupTimeout,24000);
    }
    private void finishMode(){mode=Mode.IDLE;handler.removeCallbacks(followupTimeout);}

    private void inputDialog(String title,String hint,java.util.function.Consumer<String> onConfirm){
        EditText e=new EditText(ctx);e.setSingleLine(true);e.setHint(hint);e.setTextDirection(View.TEXT_DIRECTION_RTL);
        LinearLayout holder=new LinearLayout(ctx);holder.setPadding(dp(20),0,dp(20),0);holder.addView(e,new LinearLayout.LayoutParams(-1,-2));
        new AlertDialog.Builder(ctx).setTitle(title).setView(holder).setNegativeButton("ביטול",(d,w)->{}).setPositiveButton("המשך",(d,w)->onConfirm.accept(e.getText().toString().trim())).show();
    }
    public void listen(){
        if(closed||listening)return;
        if(ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            if(ctx instanceof Activity)((Activity)ctx).requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},123);
            status("יש לאשר הרשאת מיקרופון");return;
        }
        if(!SpeechRecognizer.isRecognitionAvailable(ctx)){status("שירות זיהוי הדיבור אינו זמין");return;}
        if(tts!=null)tts.stop();
        if(recognizer!=null){recognizer.destroy();recognizer=null;}
        recognizer=SpeechRecognizer.createSpeechRecognizer(ctx);
        recognizer.setRecognitionListener(new RecognitionListener(){
            @Override public void onReadyForSpeech(Bundle b){if(listening)state.setText("מקשיבה...");}
            @Override public void onBeginningOfSpeech(){state.setText("שומעת אותך...");}
            @Override public void onRmsChanged(float rms){if(listening)orb.setEnergy(Math.min(1f,Math.max(0,rms)/12f));}
            @Override public void onBufferReceived(byte[] b){}
            @Override public void onEndOfSpeech(){if(listening)state.setText("מעבדת פקודה...");}
            @Override public void onError(int code){if(!listening)return;finishListening();status(code==SpeechRecognizer.ERROR_NO_MATCH||code==SpeechRecognizer.ERROR_SPEECH_TIMEOUT?"לא זיהיתי דיבור, נסה שוב":"שגיאת זיהוי קול: "+code);}
            @Override public void onResults(Bundle b){if(!listening)return;finishListening();ArrayList<String> words=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(words==null||words.isEmpty()){status("לא זיהיתי מילים");return;}String command=words.get(0);transcript.setText("שמעתי: "+command);handle(command);}
            @Override public void onPartialResults(Bundle b){ArrayList<String> p=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(p!=null&&!p.isEmpty())transcript.setText(p.get(0));}
            @Override public void onEvent(int e,Bundle b){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"he-IL");i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"he-IL");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);
        listening=true;state.setText("פותחת מיקרופון...");mic.setText("■ עצור האזנה");orb.setActive(true);
        handler.postDelayed(hardTimeout,12000);
        try{recognizer.startListening(i);}catch(Exception ex){finishListening();status("הפעלת זיהוי הדיבור נכשלה");}
    }
    private void finishListening(){handler.removeCallbacks(hardTimeout);listening=false;orb.setEnergy(0);orb.setActive(false);if(recognizer!=null){recognizer.cancel();recognizer.destroy();recognizer=null;}mic.setText("🎙  התחילי להקשיב");}
    private void stopListening(){finishListening();status("האזנה הופסקה");}
    private String normalize(String s){return s.toLowerCase(he).replaceAll("[\\u0591-\\u05c7]", "").replaceAll("[^\\p{L}\\p{N} ]", " ").replaceAll("\\s+"," ").trim();}
    private String removeCommandPrefix(String s, String regex){return s.replaceFirst(regex," ").trim();}
    private void handle(String input){
        String s=normalize(input);
        handler.removeCallbacks(followupTimeout);
        if(mode==Mode.CALL_NAME){finishMode();callByVoice(s);return;}
        if(mode==Mode.CONTACT_DISAMBIGUATION){chooseByVoice(s);return;}
        if(mode==Mode.CALL_CONFIRM){
            if(isYes(s)){String number=pendingNumber,n=pendingName;finishMode();placeCall(number,n);}
            else {finishMode();say("השיחה בוטלה");}return;
        }
        if(mode==Mode.MESSAGE_RECIPIENT){mode=Mode.IDLE;resolveForMessage(s);return;}
        if(mode==Mode.MESSAGE_BODY){pendingBody=input.trim();mode=Mode.MESSAGE_CONFIRM;
            sayAndListen("ההודעה ל"+pendingName+": "+pendingBody+". לשלוח? אמרו כן או בטל.");return;}
        if(mode==Mode.MESSAGE_CONFIRM){if(isYes(s))sendPendingMessage();else{finishMode();say("ההודעה בוטלה");}return;}
        if(mode==Mode.COMMAND_FOLLOWUP){finishMode();navigate(s);return;}
        if(s.matches(".*(נווט|קחי אותי|סעי ל|תיקחי אותי).*")){
            String d=removeCommandPrefix(s,"^.*?(?:נווטי|נווט|קחי אותי|תיקחי אותי|סעי ל)\\s*");
            if(d.isEmpty()){mode=Mode.COMMAND_FOLLOWUP;sayAndListen("לאן לנווט?");}else navigate(d);
        }else if(s.matches("^(תתקשרי|תתקשר|התקשרי|התקשר|חייגי|חייג).*")){
            String name=removeCommandPrefix(s,"^(תתקשרי|תתקשר|התקשרי|התקשר|חייגי|חייג)\\s*(ל)?");
            if(name.isEmpty()){mode=Mode.CALL_NAME;sayAndListen("למי להתקשר?");}else callByVoice(name);
        }else if(s.contains("הודעה")||s.contains("וואטסאפ")||s.contains("ווטסאפ")||s.contains("sms")){
            requestedChannel=(s.contains("sms")||s.contains("אס אמ אס"))?"sms":"whatsapp";
            String name=removeCommandPrefix(s,"^.*?(?:וואטסאפ|ווטסאפ|sms|אס אמ אס|הודעה)\\s*(ל)?");
            if(name.isEmpty()){mode=Mode.MESSAGE_RECIPIENT;sayAndListen("למי לשלוח הודעה?");}else resolveForMessage(name);
        }else if(s.contains("שעה")){Calendar c=Calendar.getInstance();say("השעה "+String.format(he,"%02d:%02d",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE)));}
        else if(s.contains("שלום")||s.contains("היי")){say("שלום, אני מור איי. אפשר להתקשר, לשלוח הודעה או לנווט בוויז.");}
        else{say("הבנתי את הדיבור, אבל עדיין לא חיברנו שרת שיחה עם בינה מלאכותית.");}
    }
    private boolean isYes(String s){return s.equals("כן")||s.contains("אישור")||s.equals("תשלחי")||s.equals("שלחי")||s.equals("תתקשרי");}
    private int levenshtein(String a,String b){int[] prev=new int[b.length()+1];for(int j=0;j<=b.length();j++)prev[j]=j;
        for(int i=1;i<=a.length();i++){int[] cur=new int[b.length()+1];cur[0]=i;for(int j=1;j<=b.length();j++)cur[j]=Math.min(Math.min(cur[j-1]+1,prev[j]+1),prev[j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1));prev=cur;}return prev[b.length()];}
    private List<Contact> findContacts(String query){
        List<Contact> found=new ArrayList<>();String q=normalize(query);
        try(Cursor c=ctx.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null)){
            if(c!=null)while(c.moveToNext()){
                String name=c.getString(0),phone=c.getString(1);if(name==null||phone==null)continue;
                String n=normalize(name);int score=n.equals(q)?110:n.startsWith(q)?90:n.contains(q)?75:0;
                for(String part:n.split(" ")){if(part.equals(q))score=Math.max(score,78);}
                if(score==0 && q.length()>3){int d=levenshtein(n,q);if(d<=2)score=65-d*8;}
                if(score>0){boolean duplicate=false;for(Contact old:found){if(old.phone.equals(phone)){duplicate=true;break;}}if(!duplicate)found.add(new Contact(name,phone,score));}
            }
        }catch(Exception ignored){}
        found.sort((a,b)->Integer.compare(b.score,a.score));return found;
    }
    private void withResolvedContact(String query, java.util.function.Consumer<Contact> done){
        if(query.matches("[+0-9 ()-]{6,25}")){done.accept(new Contact(query,query.replaceAll("[^+0-9]",""),100));return;}
        if(ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
            if(ctx instanceof Activity)((Activity)ctx).requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},124);
            say("צריך לאשר גישה לאנשי קשר פעם אחת");return;
        }
        List<Contact> found=findContacts(query);
        if(found.isEmpty()){say("לא מצאתי איש קשר בשם "+query+". אפשר לשמור אותו באנשי הקשר של הטלפון ולנסות שוב.");return;}
        if(found.get(0).score>=90 && (found.size()==1 || found.get(0).score-found.get(1).score>=15)){done.accept(found.get(0));return;}
        alternatives=found.subList(0,Math.min(3,found.size()));
        // Keep pending action type through contact disambiguation.
        mode=Mode.CONTACT_DISAMBIGUATION;
        StringBuilder b=new StringBuilder("מצאתי כמה אנשי קשר. ");
        for(int i=0;i<alternatives.size();i++)b.append(i+1).append(" ").append(alternatives.get(i).name).append(". ");
        sayAndListen(b+"אמור ראשון, שני או שלישי.");
    }
    private void chooseByVoice(String s){int i=s.contains("ראשון")||s.equals("אחד")?0:s.contains("שני")||s.equals("שתיים")?1:s.contains("שלישי")||s.equals("שלוש")?2:-1;
        if(i<0||i>=alternatives.size()){sayAndListen("לא זיהיתי איזו אפשרות. אמור ראשון, שני או שלישי");return;}
        Contact c=alternatives.get(i);finishMode();if("message".equals(pendingChannel)){setRecipient(c);}else startCall(c);
    }
    private void callByVoice(String name){pendingChannel="call";withResolvedContact(name,this::startCall);}
    private void startCall(Contact c){pendingName=c.name;pendingNumber=c.phone;
        if(ctx.checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){
            if(ctx instanceof Activity)((Activity)ctx).requestPermissions(new String[]{Manifest.permission.CALL_PHONE},125);
            say("צריך לאשר הרשאת טלפון פעם אחת. לאחר האישור אמור שוב להתקשר ל"+c.name);return;
        }
        placeCall(c.phone,c.name);
    }
    private void placeCall(String phone,String name){say("מתקשרת ל"+name);handler.postDelayed(()->{
        try{Intent i=new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+Uri.encode(phone)));open(i);}catch(Exception ex){say("לא הצלחתי לחייג");}
        },900);
    }
    private void resolveForMessage(String name){pendingChannel="message";withResolvedContact(name,this::setRecipient);}
    private void setRecipient(Contact c){pendingName=c.name;pendingNumber=c.phone;mode=Mode.MESSAGE_BODY;
        sayAndListen("מה לכתוב ל"+c.name+"?");}
    private void sendPendingMessage(){String ch=requestedChannel,number=pendingNumber,body=pendingBody,name=pendingName;finishMode();
        if("sms".equals(ch)){
            if(ctx.checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED){
                if(ctx instanceof Activity)((Activity)ctx).requestPermissions(new String[]{Manifest.permission.SEND_SMS},126);
                say("צריך לאשר הרשאת שליחת SMS. נא לומר את ההודעה מחדש אחרי האישור.");return;
            }
            try{SmsManager.getDefault().sendTextMessage(number,null,body,null,null);say("נשלחה הודעת SMS ל"+name);}
            catch(Exception e){say("שליחת SMS נכשלה");}
        }else{
            say("פותחת וואטסאפ עם ההודעה ל"+name+". יש לאשר שליחה בוואטסאפ.");
            String url="https://wa.me/"+intl(number)+"?text="+Uri.encode(body);
            handler.postDelayed(()->open(new Intent(Intent.ACTION_VIEW,Uri.parse(url))),1100);
        }
    }
    private void navigate(String dest){if(dest.isEmpty()){status("חסר יעד");return;}say("פותחת וייז ל"+dest);
        open(new Intent(Intent.ACTION_VIEW,Uri.parse("https://waze.com/ul?q="+Uri.encode(dest)+"&navigate=yes&utm_source=morai")));
    }
    private static class Contact {String name,phone;int score;Contact(String name,String phone,int score){this.name=name;this.phone=phone;this.score=score;}}
    private boolean isNumber(String s){return s.matches("[+0-9 ()-]{6,25}");}
    private void withContact(String query,java.util.function.Consumer<String> callback){
        if(query==null||query.trim().isEmpty()){inputDialog("בחירת נמען","שם או מספר טלפון",q->withContact(q,callback));return;}
        if(isNumber(query)){callback.accept(query.replaceAll("[^+0-9]",""));return;}
        if(ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
            if(ctx instanceof Activity){((Activity)ctx).requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},124);}
            status("אשר אנשי קשר, ונסה שוב");return;
        }
        List<Contact> found=new ArrayList<>();String q=normalize(query);
        try(Cursor c=ctx.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null)){
            if(c!=null)while(c.moveToNext()){String n=c.getString(0),p=c.getString(1);if(n==null||p==null)continue;String norm=normalize(n);int score=norm.equals(q)?100:norm.startsWith(q)?80:norm.contains(q)?60:0;if(score>0)found.add(new Contact(n,p,score));}
        }catch(Exception e){status("לא ניתן לקרוא אנשי קשר");return;}
        Collections.sort(found,(a,b)->Integer.compare(b.score,a.score));
        if(found.isEmpty()){new AlertDialog.Builder(ctx).setTitle("לא נמצא איש קשר").setMessage("אם השם נשמר רק ב-WhatsApp, שמור אותו גם באנשי הקשר של הטלפון, או הזן מספר ידנית.").setPositiveButton("הזן מספר",(d,w)->inputDialog("מספר טלפון","05...",callback)).setNegativeButton("ביטול",null).show();return;}
        if(found.size()==1||found.get(0).score==100&&found.get(0).score>found.get(1).score){callback.accept(found.get(0).phone);return;}
        int count=Math.min(found.size(),8);String[] names=new String[count];for(int i=0;i<count;i++)names[i]=found.get(i).name+" · "+found.get(i).phone;
        new AlertDialog.Builder(ctx).setTitle("למי התכוונת?").setItems(names,(d,which)->callback.accept(found.get(which).phone)).setNegativeButton("ביטול",null).show();
    }
    private void dialContact(String query){withContact(query,number->{say("פותחת חיוג. אשר את השיחה בטלפון");open(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(number))));});}
    private void chooseMessage(String name){withContact(name,number->{new AlertDialog.Builder(ctx).setTitle("בחר סוג הודעה").setItems(new String[]{"WhatsApp","SMS"},(d,w)->compose(number,w==0)).setNegativeButton("ביטול",null).show();});}
    private void whatsapp(String name){withContact(name,number->compose(number,true));}
    private String intl(String raw){String p=raw.replaceAll("[^0-9]","");if(p.startsWith("00"))p=p.substring(2);else if(p.startsWith("0"))p="972"+p.substring(1);return p;}
    private void compose(String number,boolean whats){inputDialog(whats?"הודעת WhatsApp":"הודעת SMS","כתוב הודעה",body->{if(body.trim().isEmpty()){status("ההודעה ריקה");return;}
        new AlertDialog.Builder(ctx).setTitle("אישור הודעה").setMessage("אל: "+number+"\n\n"+body+"\n\nתיפתח אפליקציית ההודעות; בדוק את הנמען ואשר שליחה שם.")
        .setNegativeButton("ביטול",null).setPositiveButton("פתח הודעה",(d,w)->{
            if(whats){String url="https://wa.me/"+intl(number)+"?text="+Uri.encode(body);open(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
            else{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"+number));i.putExtra("sms_body",body);open(i);}
        }).show();});}
    private void applyVoice(){if(tts==null||preferredVoice.isEmpty())return;for(Voice v:tts.getVoices()){if(v.getName().equals(preferredVoice)){tts.setVoice(v);break;}}}
    private void chooseVoice(){if(tts==null){status("מנוע הקול עדיין נטען");return;}Set<Voice> voices=tts.getVoices();if(voices==null||voices.isEmpty()){status("לא נמצאו קולות");return;}
        List<Voice> list=new ArrayList<>();for(Voice v:voices){if(v.getLocale().getLanguage().equals("he"))list.add(v);}
        if(list.isEmpty()){status("אין קולות עבריים מותקנים. אפשר להתקין קול עברי בהגדרות הטלפון.");return;}
        String[] labels=new String[list.size()];for(int i=0;i<list.size();i++)labels[i]=list.get(i).getName()+" ("+list.get(i).getLocale()+")";
        new AlertDialog.Builder(ctx).setTitle("בחירת קול עברי זמין").setSingleChoiceItems(labels,-1,(d,w)->{preferredVoice=list.get(w).getName();ctx.getSharedPreferences("morai",0).edit().putString("voice",preferredVoice).apply();applyVoice();d.dismiss();say("שלום, זה הקול שבחרת");}).setNegativeButton("ביטול",null).show();
    }
    public void close(){closed=true;handler.removeCallbacks(followupTimeout);handler.removeCallbacks(hardTimeout);if(recognizer!=null){recognizer.cancel();recognizer.destroy();recognizer=null;}if(tts!=null){tts.stop();tts.shutdown();tts=null;}}
}
