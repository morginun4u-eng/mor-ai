package com.mornof.morai;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class VoicePanel {
    private final Context context;
    private final Runnable settingsAction;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Locale he = new Locale("he", "IL");
    private final int WHITE = Color.WHITE, MUTED = 0xff9caec9, CYAN = 0xff25d9cf;
    private LinearLayout root;
    private TextView status, heard, subtitle;
    private Button mic;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean listening = false, closed = false;
    private final Runnable timeout = () -> {
        if (listening) { listening = false; if (recognizer != null) recognizer.cancel(); setStatus("לא שמעתי דיבור. נסה שוב."); }
    };

    public VoicePanel(Context context, Runnable settingsAction) {
        this.context = context;
        this.settingsAction = settingsAction;
        buildView();
        tts = new TextToSpeech(context, result -> {
            if (result == TextToSpeech.SUCCESS && tts != null) tts.setLanguage(he);
        });
    }

    private GradientDrawable bg(int fill, int radius, int border) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill); d.setCornerRadius(dp(radius));
        if (border != 0) d.setStroke(dp(1), border);
        return d;
    }
    private int dp(int value) { return (int)(value * context.getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView v = new TextView(context);
        v.setText(s); v.setTextSize(size); v.setTextColor(color); v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private void add(LinearLayout parent, View child, int top, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(top), 0, dp(bottom)); parent.addView(child, lp);
    }
    private Button button(String label, int background, int foreground) {
        Button b = new Button(context); b.setAllCaps(false); b.setText(label);
        b.setTextSize(17); b.setTextColor(foreground); b.setBackground(bg(background, 20, 0));
        b.setMinHeight(dp(58)); return b;
    }
    private void buildView() {
        ScrollView scroll = new ScrollView(context); scroll.setFillViewport(true);
        root = new LinearLayout(context); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(dp(24), dp(45), dp(24), dp(28));
        root.setBackgroundColor(0xff081322); scroll.addView(root);
        TextView mark = text("✦  MOR AI", 36, WHITE, true); add(root, mark, 12, 3);
        subtitle = text("העוזרת הקולית שלך לרכב", 16, MUTED, false); add(root, subtitle, 0, 36);
        TextView circle = text("◉", 93, CYAN, true); circle.setBackground(bg(0xff11293a, 100, 0xff235b66));
        LinearLayout.LayoutParams circleLp = new LinearLayout.LayoutParams(dp(190), dp(190));
        circleLp.setMargins(0, 0, 0, dp(26)); root.addView(circle, circleLp);
        status = text("מוכנה להקשיב", 25, WHITE, true); add(root, status, 0, 13);
        heard = text("לחץ על המיקרופון ואמור פקודה בעברית", 15, MUTED, false);
        add(root, heard, 0, 30);
        mic = button("🎙  התחל לדבר", 0xff19cabe, 0xff051a20);
        mic.setOnClickListener(v -> { if (listening) stop(); else listen(); }); add(root, mic, 0, 16);
        Button maps = button("⌖  ניווט למיקום", 0xff172c42, WHITE);
        maps.setOnClickListener(v -> { heard.setText("אמור: נווטי לכתובת... "); listen(); }); add(root, maps, 0, 10);
        Button settings = button("⚙  הגדרות העוזרת בטלפון", 0xff172c42, WHITE);
        settings.setOnClickListener(v -> { try { settingsAction.run(); } catch (Exception e) { setStatus("פתח הגדרות > יישומים > עוזרת דיגיטלית"); } });
        add(root, settings, 0, 26);
        TextView note = text("אפשר לומר: שלום · מה השעה · נווטי לחיפה\nגרסת ניסיון — עדיין ללא מנוע AI חופשי", 13, MUTED, false);
        add(root, note, 0, 0);
        this.view = scroll;
    }
    private View view;
    public View view() { return view; }
    private void setStatus(String s) { status.setText(s); mic.setText("🎙  התחל לדבר"); }
    private void stop() {
        handler.removeCallbacks(timeout); listening = false;
        if (recognizer != null) recognizer.cancel();
        setStatus("ההאזנה הופסקה");
    }
    public void listen() {
        if (closed || listening) return;
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            setStatus("יש לאשר הרשאת מיקרופון"); return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            setStatus("אין שירות זיהוי דיבור זמין בטלפון"); return;
        }
        if (tts != null) tts.stop();
        if (recognizer != null) { recognizer.destroy(); recognizer = null; }
        recognizer = SpeechRecognizer.createSpeechRecognizer(context);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle b) { status.setText("מקשיבה לך..."); }
            @Override public void onBeginningOfSpeech() { status.setText("שומעת אותך..."); }
            @Override public void onRmsChanged(float f) { }
            @Override public void onBufferReceived(byte[] b) { }
            @Override public void onEndOfSpeech() { status.setText("מעבדת את הבקשה..."); }
            @Override public void onError(int e) {
                if (!listening) return;
                listening = false; handler.removeCallbacks(timeout);
                setStatus(e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                        ? "לא שמעתי. לחץ ונסה שוב." : "שגיאת זיהוי דיבור (" + e + "). נסה שוב.");
            }
            @Override public void onResults(Bundle b) {
                if (!listening) return;
                listening = false; handler.removeCallbacks(timeout);
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r == null || r.isEmpty()) setStatus("לא זיהיתי מילים. נסה שוב.");
                else { heard.setText("אמרת: " + r.get(0)); respond(r.get(0)); }
            }
            @Override public void onPartialResults(Bundle b) { }
            @Override public void onEvent(int t, Bundle b) { }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "he-IL");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "he-IL");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L);
        listening = true; status.setText("פותחת מיקרופון..."); mic.setText("■  עצור האזנה");
        handler.postDelayed(timeout, 9000);
        try { recognizer.startListening(i); }
        catch (Exception e) { listening = false; handler.removeCallbacks(timeout); setStatus("לא ניתן להפעיל מיקרופון"); }
    }
    private void say(String response) {
        setStatus(response);
        if (tts != null) tts.speak(response, TextToSpeech.QUEUE_FLUSH, null, "mor_reply");
    }
    private void respond(String input) {
        String s = input.trim().toLowerCase(he);
        if (s.contains("נווט") || s.contains("קחי אותי") || s.contains("תיקחי אותי") || s.contains("סעי ל")) {
            String dest = s.replaceFirst("^(נווטי|נווט|קחי אותי|תיקחי אותי|סעי ל)\\s*", "").trim();
            if (dest.isEmpty()) { say("לאן תרצה לנסוע?"); return; }
            say("פותחת ניווט אל " + dest);
            Intent nav = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest)));
            nav.setPackage("com.google.android.apps.maps"); nav.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { context.startActivity(nav); } catch (Exception e) {
                Intent backup = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(dest)));
                backup.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { context.startActivity(backup); } catch (Exception ignored) { say("לא הצלחתי לפתוח ניווט"); }
            }
        } else if (s.contains("שעה")) {
            Calendar c = Calendar.getInstance();
            say("השעה עכשיו " + String.format(he, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)));
        } else if (s.contains("שלום") || s.contains("היי")) say("שלום! אני מור איי איי. במה אוכל לעזור?");
        else say("שמעתי אותך. כרגע אני תומכת בניווט, שעה וברכות. שיחה חכמה תתווסף בגרסה הבאה.");
    }
    public void close() {
        closed = true; handler.removeCallbacks(timeout);
        if (recognizer != null) { recognizer.cancel(); recognizer.destroy(); recognizer = null; }
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
    }
}
