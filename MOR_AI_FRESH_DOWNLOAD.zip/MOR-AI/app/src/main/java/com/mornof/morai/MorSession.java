package com.mornof.morai;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.service.voice.VoiceInteractionSession;
import android.view.View;

public class MorSession extends VoiceInteractionSession {
    private VoicePanel panel;
    public MorSession(Context context) { super(context); }
    @Override public View onCreateContentView() {
        panel = new VoicePanel(getContext(), null);
        return panel.view();
    }
    @Override public void onShow(Bundle args, int flags) {
        super.onShow(args, flags);
        if (panel != null) panel.listen();
    }
    @Override public void onDestroy() {
        if (panel != null) panel.close();
        super.onDestroy();
    }
}
