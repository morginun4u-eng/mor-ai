package com.mornof.morai;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.app.AlertDialog;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** MOR AI V3 local voice/action prototype. Does not transmit contacts or messages to a server. */
public class VoicePanel {
    private final Context ctx;
    private final Runnable settingsAction;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Locale he = new Locale("he", "IL");
    private final int BACK=0xff071322, PANEL=0xff15273c, AQUA=0xff28dfd0, MUTED=0xff9dafc8;
    private TextView state, transcript, orb;
    private Button mic;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean listening=false, closed=false;
    private String preferredVoice="";
    private View view;
    private final Runnable hardTimeout = () -> { if(listening){ stopListening(); status("לא התקבל דיבור — אפשר לנסות שוב"); }};

    public VoicePanel(Context ctx, Runnable settingsAction) {
        this.ctx=ctx; this.settingsAction=settingsAction;
        build();
        tts=new TextToSpeech(ctx, result -> {
            if(result==TextToSpeech.SUCCESS && tts!=null) {
                tts.setLanguage(he);
                preferredVoice=ctx.getSharedPreferences("morai",0).getString("voice", "");
                applyVoice();
            }
        });
    }
    private int dp(int p){return (int)(p*ctx.getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable background(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable(); d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private TextView txt(String value,int sp,int color,boolean bold){TextView t=new TextView(ctx);t.setText(value);t.setTextColor(color);t.setTextSize(sp);t.setGravity(Gravity.CENTER);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void add(LinearLayout p,View v,int top,int bottom){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(top),0,dp(bottom));p.addView(v,lp);}
    private Button button(String label, int bg){Button b=new Button(ctx);b.setAllCaps(false);b.setText(label);b.setTextSize(17);b.setTextColor(bg==AQUA?BACK:Color.WHITE);b.setBackground(background(bg,22,0));b.setMinHeight(dp(58));return b;}
    private void build(){
        ScrollView s=new ScrollView(ctx); s.setFillViewport(true);s.setBackgroundColor(BACK);
        LinearLayout root=new LinearLayout(ctx);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setPadding(dp(22),dp(32),dp(22),dp(30));s.addView(root);
        add(root,txt("✦  MOR AI",36,Color.WHITE,true),5,3);
        add(root,txt("VOICE DRIVE  •  גרסת ניסיון 3.0",13,MUTED,false),0,26);
        orb=txt("◉",95,AQUA,true);orb.setBackground(background(0xff102e3a,160,0xff247e81));
        LinearLayout.LayoutParams orbParams=new LinearLayout.LayoutParams(dp(190),dp(190));orbParams.setMargins(0,0,0,dp(24));root.addView(orb,orbParams);
        state=txt("מוכנה לשמוע אותך",23,Color.WHITE,true);add(root,state,0,8);
        transcript=txt("אמור: נווטי לירושלים, התקשרי לדני, שלחי SMS לדני",14,MUTED,false);add(root,transcript,0,24);
        mic=button("🎙  התחל לדבר",AQUA);mic.setOnClickListener(v->{if(listening)stopListening();else listen();});add(root,mic,0,11);
        Button waze=button("⌖  ניווט עם Waze",PANEL);waze.setOnClickListener(v->inputDialog("לאן לנווט ב-Waze?","כתובת או מקום",this::navigate));add(root,waze,0,9);
        Button call=button("☎  התקשר לאיש קשר",PANEL);call.setOnClickListener(v->inputDialog("למי להתקשר?","שם איש קשר או מספר",this::dialContact));add(root,call,0,9);
        Button message=button("✉  SMS / WhatsApp",PANEL);message.setOnClickListener(v->inputDialog("למי לשלוח הודעה?","שם איש קשר או מספר",this::chooseMessage));add(root,message,0,9);
        Button voices=button("♫  בחירת קול העוזרת",PANEL);voices.setOnClickListener(v->chooseVoice());add(root,voices,0,9);
        Button ass=button("⚙  עוזרת ברירת מחדל",PANEL);ass.setOnClickListener(v->{try{if(settingsAction!=null)settingsAction.run();else open(new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS));}catch(Exception e){status("פתח הגדרות > יישומים > עוזרת דיגיטלית");}});add(root,ass,0,18);
        add(root,txt("בגרסה זו פקודות מקומיות. שיחה חופשית עם AI דורשת שרת מאובטח וחיבור נפרד. הודעות נשלחות רק לאחר אישור שלך באפליקציית היעד.",12,MUTED,false),0,0);
        view=s;
    }
    public View view(){return view;}
    private void status(String v){state.setText(v);mic.setText("🎙  התחל לדבר");orb.clearAnimation();}
    private void open(Intent i){try{i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);ctx.startActivity(i);}catch(Exception e){status("לא נמצאה אפליקציה מתאימה");}}
    private void say(String v){status(v);if(tts!=null)tts.speak(v,TextToSpeech.QUEUE_FLUSH,null,"mor"+System.currentTimeMillis());}
    private void inputDialog(String title,String hint,java.util.function.Consumer<String> onConfirm){
        EditText e=new EditText(ctx);e.setSingleLine(true);e.setHint(hint);e.setTextDirection(View.TEXT_DIRECTION_RTL);
        LinearLayout holder=new LinearLayout(ctx);holder.setPadding(dp(20),0,dp(20),0);holder.addView(e,new LinearLayout.LayoutParams(-1,-2));
        new AlertDialog.Builder(ctx).setTitle(title).setView(holder).setNegativeButton("ביטול",(d,w)->{}).setPositiveButton("המשך",(d,w)->onConfirm.accept(e.getText().toString().trim())).show();
    }
    public void listen(){
        if(closed||listening)return;
        if(ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            if(ctx instanceof Activity)((Activity)ctx).requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},123);
            status("יש לאשר הרשאת מיקרופון");return;
        }
        if(!SpeechRecognizer.isRecognitionAvailable(ctx)){status("שירות זיהוי הדיבור אינו זמין");return;}
        if(tts!=null)tts.stop();
        if(recognizer!=null){recognizer.destroy();recognizer=null;}
        recognizer=SpeechRecognizer.createSpeechRecognizer(ctx);
        recognizer.setRecognitionListener(new RecognitionListener(){
            @Override public void onReadyForSpeech(Bundle b){if(listening)state.setText("מקשיבה...");}
            @Override public void onBeginningOfSpeech(){state.setText("שומעת אותך...");}
            @Override public void onRmsChanged(float rms){if(listening)orb.setScaleX(1f+Math.min(.18f,Math.max(0,rms)/40f));}
            @Override public void onBufferReceived(byte[] b){}
            @Override public void onEndOfSpeech(){if(listening)state.setText("מעבדת פקודה...");}
            @Override public void onError(int code){if(!listening)return;finishListening();status(code==SpeechRecognizer.ERROR_NO_MATCH||code==SpeechRecognizer.ERROR_SPEECH_TIMEOUT?"לא זיהיתי דיבור, נסה שוב":"שגיאת זיהוי קול: "+code);}
            @Override public void onResults(Bundle b){if(!listening)return;finishListening();ArrayList<String> words=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(words==null||words.isEmpty()){status("לא זיהיתי מילים");return;}String command=words.get(0);transcript.setText("שמעתי: "+command);handle(command);}
            @Override public void onPartialResults(Bundle b){ArrayList<String> p=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(p!=null&&!p.isEmpty())transcript.setText(p.get(0));}
            @Override public void onEvent(int e,Bundle b){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"he-IL");i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"he-IL");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);
        listening=true;state.setText("פותחת מיקרופון...");mic.setText("■ עצור האזנה");
        AlphaAnimation a=new AlphaAnimation(.5f,1f);a.setDuration(650);a.setRepeatCount(Animation.INFINITE);a.setRepeatMode(Animation.REVERSE);orb.startAnimation(a);
        handler.postDelayed(hardTimeout,12000);
        try{recognizer.startListening(i);}catch(Exception ex){finishListening();status("הפעלת זיהוי הדיבור נכשלה");}
    }
    private void finishListening(){handler.removeCallbacks(hardTimeout);listening=false;orb.setScaleX(1f);if(recognizer!=null){recognizer.cancel();recognizer.destroy();recognizer=null;}mic.setText("🎙  התחל לדבר");orb.clearAnimation();}
    private void stopListening(){finishListening();status("האזנה הופסקה");}
    private String normalize(String s){return s.toLowerCase(he).replaceAll("[\\u0591-\\u05c7]", "").replaceAll("[^\\p{L}\\p{N} ]", " ").replaceAll("\\s+"," ").trim();}
    private void handle(String input){
        String s=normalize(input);
        if(s.matches(".*(נווט|קחי אותי|סעי ל|תיקחי אותי).*")){
            String dest=s.replaceFirst("^.*?(?:נווטי|נווט|קחי אותי|תיקחי אותי|סעי ל)\\s*","").trim();
            if(dest.isEmpty()){say("לאן לנסוע?");inputDialog("יעד ב-Waze","הקלד יעד",this::navigate);}else navigate(dest);
        }else if(s.startsWith("תתקשר")||s.startsWith("התקשר")||s.startsWith("חייג")){
            dialContact(s.replaceFirst("^(תתקשרי|תתקשר|התקשרי|התקשר|חייגי|חייג)\\s*(ל)?","").trim());
        }else if(s.contains("וואטסאפ")||s.contains("ווטסאפ")||s.contains("whatsapp")){
            String name=s.replaceFirst("^.*?(?:וואטסאפ|ווטסאפ|whatsapp)\\s*(ל)?","").trim();if(name.isEmpty())inputDialog("למי ב-WhatsApp?","שם או מספר",this::whatsapp);else whatsapp(name);
        }else if(s.startsWith("שלח")||s.startsWith("שלחי")||s.startsWith("הודעה")){
            String name=s.replaceFirst("^(שלחי|שלח|הודעה)\\s*(הודעת|הודעה|אס אמ אס|sms|ל)?\\s*(ל)?","").trim();chooseMessage(name);
        }else if(s.contains("שעה")){Calendar c=Calendar.getInstance();say("השעה "+String.format(he,"%02d:%02d",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE)));}
        else if(s.contains("שלום")||s.contains("היי")){say("שלום, אני מור איי. אפשר לבקש ניווט, שיחה או הודעה.");}
        else{say("שמעתי אותך, אבל עדיין לא חיברנו מנוע שיחה חופשי. אפשר לומר נווטי, התקשרי או שלחי הודעה.");}
    }
    private void navigate(String dest){if(dest.isEmpty()){status("חסר יעד");return;}say("פותחת וייז ל"+dest);
        open(new Intent(Intent.ACTION_VIEW,Uri.parse("https://waze.com/ul?q="+Uri.encode(dest)+"&navigate=yes&utm_source=morai")));
    }
    private static class Contact {String name,phone;int score;Contact(String name,String phone,int score){this.name=name;this.phone=phone;this.score=score;}}
    private boolean isNumber(String s){return s.matches("[+0-9 ()-]{6,25}");}
    private void withContact(String query,java.util.function.Consumer<String> callback){
        if(query==null||query.trim().isEmpty()){inputDialog("בחירת נמען","שם או מספר טלפון",q->withContact(q,callback));return;}
        if(isNumber(query)){callback.accept(query.replaceAll("[^+0-9]",""));return;}
        if(ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
            if(ctx instanceof Activity){((Activity)ctx).requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},124);}
            status("אשר אנשי קשר, ונסה שוב");return;
        }
        List<Contact> found=new ArrayList<>();String q=normalize(query);
        try(Cursor c=ctx.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null)){
            if(c!=null)while(c.moveToNext()){String n=c.getString(0),p=c.getString(1);if(n==null||p==null)continue;String norm=normalize(n);int score=norm.equals(q)?100:norm.startsWith(q)?80:norm.contains(q)?60:0;if(score>0)found.add(new Contact(n,p,score));}
        }catch(Exception e){status("לא ניתן לקרוא אנשי קשר");return;}
        Collections.sort(found,(a,b)->Integer.compare(b.score,a.score));
        if(found.isEmpty()){new AlertDialog.Builder(ctx).setTitle("לא נמצא איש קשר").setMessage("אם השם נשמר רק ב-WhatsApp, שמור אותו גם באנשי הקשר של הטלפון, או הזן מספר ידנית.").setPositiveButton("הזן מספר",(d,w)->inputDialog("מספר טלפון","05...",callback)).setNegativeButton("ביטול",null).show();return;}
        if(found.size()==1||found.get(0).score==100&&found.get(0).score>found.get(1).score){callback.accept(found.get(0).phone);return;}
        int count=Math.min(found.size(),8);String[] names=new String[count];for(int i=0;i<count;i++)names[i]=found.get(i).name+" · "+found.get(i).phone;
        new AlertDialog.Builder(ctx).setTitle("למי התכוונת?").setItems(names,(d,which)->callback.accept(found.get(which).phone)).setNegativeButton("ביטול",null).show();
    }
    private void dialContact(String query){withContact(query,number->{say("פותחת חיוג. אשר את השיחה בטלפון");open(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(number))));});}
    private void chooseMessage(String name){withContact(name,number->{new AlertDialog.Builder(ctx).setTitle("בחר סוג הודעה").setItems(new String[]{"WhatsApp","SMS"},(d,w)->compose(number,w==0)).setNegativeButton("ביטול",null).show();});}
    private void whatsapp(String name){withContact(name,number->compose(number,true));}
    private String intl(String raw){String p=raw.replaceAll("[^0-9]","");if(p.startsWith("00"))p=p.substring(2);else if(p.startsWith("0"))p="972"+p.substring(1);return p;}
    private void compose(String number,boolean whats){inputDialog(whats?"הודעת WhatsApp":"הודעת SMS","כתוב הודעה",body->{if(body.trim().isEmpty()){status("ההודעה ריקה");return;}
        new AlertDialog.Builder(ctx).setTitle("אישור הודעה").setMessage("אל: "+number+"\n\n"+body+"\n\nתיפתח אפליקציית ההודעות; בדוק את הנמען ואשר שליחה שם.")
        .setNegativeButton("ביטול",null).setPositiveButton("פתח הודעה",(d,w)->{
            if(whats){String url="https://wa.me/"+intl(number)+"?text="+Uri.encode(body);open(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
            else{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"+number));i.putExtra("sms_body",body);open(i);}
        }).show();});}
    private void applyVoice(){if(tts==null||preferredVoice.isEmpty())return;for(Voice v:tts.getVoices()){if(v.getName().equals(preferredVoice)){tts.setVoice(v);break;}}}
    private void chooseVoice(){if(tts==null){status("מנוע הקול עדיין נטען");return;}Set<Voice> voices=tts.getVoices();if(voices==null||voices.isEmpty()){status("לא נמצאו קולות");return;}
        List<Voice> list=new ArrayList<>();for(Voice v:voices){if(v.getLocale().getLanguage().equals("he"))list.add(v);}
        if(list.isEmpty()){status("אין קולות עבריים מותקנים. אפשר להתקין קול עברי בהגדרות הטלפון.");return;}
        String[] labels=new String[list.size()];for(int i=0;i<list.size();i++)labels[i]=list.get(i).getName()+" ("+list.get(i).getLocale()+")";
        new AlertDialog.Builder(ctx).setTitle("בחירת קול עברי זמין").setSingleChoiceItems(labels,-1,(d,w)->{preferredVoice=list.get(w).getName();ctx.getSharedPreferences("morai",0).edit().putString("voice",preferredVoice).apply();applyVoice();d.dismiss();say("שלום, זה הקול שבחרת");}).setNegativeButton("ביטול",null).show();
    }
    public void close(){closed=true;handler.removeCallbacks(hardTimeout);if(recognizer!=null){recognizer.cancel();recognizer.destroy();recognizer=null;}if(tts!=null){tts.stop();tts.shutdown();tts=null;}}
}
