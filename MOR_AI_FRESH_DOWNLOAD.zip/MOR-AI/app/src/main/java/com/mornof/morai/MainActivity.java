package com.mornof.morai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;

public class MainActivity extends Activity {
    private VoicePanel panel;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        panel = new VoicePanel(this, () -> startActivity(new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)));
        setContentView(panel.view());
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{ Manifest.permission.RECORD_AUDIO }, 100);
        }
    }
    @Override protected void onDestroy() {
        if (panel != null) panel.close();
        super.onDestroy();
    }
}
