package com.mornof.morai;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class VoicePanel {
    private final Context context;
    private final Runnable settingsAction;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout root;
    private TextView status;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean listening = false;
    private boolean closed = false;
    private final Locale he = new Locale("he", "IL");

    public VoicePanel(Context context, Runnable settingsAction) {
        this.context = context;
        this.settingsAction = settingsAction;
        buildView();
        tts = new TextToSpeech(context, result -> {
            if (result == TextToSpeech.SUCCESS && tts != null) {
                int supported = tts.setLanguage(he);
                if (supported == TextToSpeech.LANG_MISSING_DATA || supported == TextToSpeech.LANG_NOT_SUPPORTED) {
                    status.setText("חסר קול בעברית. התקן נתוני הקראה בעברית בהגדרות הטלפון.");
                }
            }
        });
    }

    private TextView text(String s, int size, int color) {
        TextView v = new TextView(context);
        v.setText(s); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER); v.setPadding(18, 18, 18, 18);
        return v;
    }
    private Button button(String s) {
        Button b = new Button(context); b.setText(s); b.setAllCaps(false);
        return b;
    }
    private void buildView() {
        root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(11, 19, 35)); root.setPadding(32, 48, 32, 32);
        TextView title = text("MOR AI", 37, Color.WHITE); title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        root.addView(text("העוזרת הקולית שלך לרכב • גרסת ניסיון", 16, 0xffb7c9df));
        status = text("שלום! לחצו על המיקרופון ודברו בעברית.", 20, Color.WHITE);
        root.addView(status);
        Button mic = button("🎙  דבר איתי");
        mic.setOnClickListener(v -> listen()); root.addView(mic);
        Button settings = button("הגדרות העוזרת בטלפון");
        settings.setOnClickListener(v -> {
            try {
                if (settingsAction != null) settingsAction.run();
                else context.startActivity(new Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e) { status.setText("פתח הגדרות > יישומים > אפליקציות ברירת מחדל > אפליקציית עוזר דיגיטלי"); }
        }); root.addView(settings);
        root.addView(text("דוגמאות: 'מה השעה', 'נווטי לתל אביב', 'שלום'", 14, 0xff9eb4cb));
    }
    public View view() { return root; }
    public void listen() {
        if (closed || listening) return;
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.setText("צריך לאשר הרשאת מיקרופון באפליקציה."); return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            status.setText("אין שירות זיהוי דיבור בטלפון. יש לבדוק זיהוי דיבור של Google."); return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) { status.setText("מקשיבה לך..."); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float f) { }
                @Override public void onBufferReceived(byte[] b) { }
                @Override public void onEndOfSpeech() { status.setText("מעבדת את מה שאמרת..."); }
                @Override public void onError(int error) {
                    listening = false;
                    status.setText(error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                        ? "לא שמעתי. אפשר לנסות שוב." : "זיהוי הדיבור לא הצליח (קוד " + error + "). נסה שוב.");
                }
                @Override public void onResults(Bundle b) {
                    listening = false;
                    ArrayList<String> matches = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) respond(matches.get(0));
                    else status.setText("לא זיהיתי מילים.");
                }
                @Override public void onPartialResults(Bundle b) { }
                @Override public void onEvent(int t, Bundle b) { }
            });
        }
        if (tts != null) tts.stop();
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "he-IL");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        listening = true;
        status.setText("פותחת מיקרופון...");
        try { recognizer.startListening(intent); }
        catch (Exception e) { listening = false; status.setText("שגיאה בפתיחת המיקרופון: " + e.getMessage()); }
    }
    private void say(String message) {
        status.setText(message);
        if (tts != null) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "MOR_AI_REPL");
    }
    private void respond(String heard) {
        String s = heard.trim().toLowerCase(he);
        if (s.contains("נווט") || s.contains("קחי אותי") || s.contains("תיקחי אותי") || s.contains("סעי ל")) {
            String destination = s.replaceFirst("^(נווטי|נווט|קחי אותי|תיקחי אותי|סעי ל)\\s*", "").trim();
            if (destination.isEmpty()) { say("לאן תרצה לנסוע?"); return; }
            say("פותחת ניווט אל " + destination);
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(destination)));
            i.setPackage("com.google.android.apps.maps");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { context.startActivity(i); }
            catch (Exception e) {
                Intent fallback = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(destination)));
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { context.startActivity(fallback); } catch (Exception ignored) { say("לא הצלחתי לפתוח מפות."); }
            }
        } else if (s.contains("שעה")) {
            Calendar c = Calendar.getInstance();
            say("השעה עכשיו " + String.format(he, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)));
        } else if (s.contains("שלום") || s.contains("היי")) {
            say("שלום! אני מור איי איי, העוזרת הקולית שלך. מה תרצה לעשות?");
        } else if (s.contains("מי את") || s.contains("מה את")) {
            say("אני מור איי איי, עוזרת קולית עצמאית בעברית. זו גרסת בדיקה ראשונה.");
        } else {
            say("שמעתי: " + heard + ". בגרסה הזאת אני יודעת לפתוח ניווט, לומר שעה ולענות לכמה פקודות. שיחה חכמה תתווסף בהמשך.");
        }
    }
    public void close() {
        closed = true;
        if (recognizer != null) { recognizer.cancel(); recognizer.destroy(); recognizer = null; }
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
    }
}
