package com.mornof.morai;

import android.service.voice.VoiceInteractionService;

public class MorVoiceService extends VoiceInteractionService { }
